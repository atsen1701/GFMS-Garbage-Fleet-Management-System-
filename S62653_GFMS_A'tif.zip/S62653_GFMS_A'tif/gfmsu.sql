-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2024 at 10:39 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gfmsu`
--

-- --------------------------------------------------------

--
-- Table structure for table `checkin`
--

CREATE TABLE `checkin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `plate_number` varchar(50) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `arrival_time` datetime DEFAULT NULL,
  `checkout_time` datetime DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `route_id` int(11) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `checkin`
--

INSERT INTO `checkin` (`id`, `name`, `plate_number`, `status`, `arrival_time`, `checkout_time`, `driver_id`, `route_id`, `remarks`, `image`) VALUES
(7, 'Naufal Rashidi', 'KEK2893', 'Arrive', '2024-06-28 10:50:00', '2024-06-28 10:50:00', 13, 3, 'Hai', 'photo_6329910367370722693_y.jpg'),
(16, 'naufal@gmail.com', 'WLQ7392', 'Arrive', '2024-06-29 02:57:00', '2024-06-30 01:53:00', 12, 1, 'Nothing', 'Slip Peperiksaan  (S202324-II).pdf'),
(17, 'naufal@gmail.com', 'KEK2893', 'Arrive', '2024-06-30 09:58:00', '2024-06-30 17:40:00', 15, 8, 'Successfully pick up', 'Slip Peperiksaan  (S202324-II).pdf'),
(18, 'admin1@gmail.com', 'KEK2893', 'Arrive', '2024-07-02 08:05:00', '2024-07-02 10:05:00', 56, 1, 'Safely arrive', 'uploads/ChooseRoute.png'),
(19, 'admin1@gmail.com', 'KER3496', 'Arrive', '2024-07-05 00:49:00', '2024-07-04 00:49:00', 55, 15, 'Nothing', 'uploads/ManagerDashboard.png'),
(20, 'admin1@gmail.com', 'PKX3483', 'Arrive', '2024-07-05 00:49:00', '2024-07-04 00:49:00', 55, 15, 'Nothing', 'uploads/Trucker.png'),
(21, 'admin1@gmail.com', 'PKX3483', 'Arrive', '2024-07-05 22:29:00', '2024-07-06 19:29:00', 12, 1, 'PED', 'uploads/Damage.png');

-- --------------------------------------------------------

--
-- Table structure for table `damagefrm`
--

CREATE TABLE `damagefrm` (
  `id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `truckid` int(11) DEFAULT NULL,
  `severity` varchar(50) DEFAULT NULL,
  `repair_status` varchar(50) DEFAULT NULL,
  `repair_date` date DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `damagefrm`
--

INSERT INTO `damagefrm` (`id`, `description`, `date`, `location`, `image`, `truckid`, `severity`, `repair_status`, `repair_date`, `cost`) VALUES
(1, 'Bin Vandalism', '2024-06-15', 'Kuala Nerus', 'Screenshot 2024-06-22 223727.png', 2, 'Sever', 'No', '2024-06-20', 480.00),
(3, 'Bin Vandalism', '2024-06-15', 'Kuala Nerus', 'Screenshot 2024-06-05 011338.png', 2, 'Sever', 'No', '2024-06-15', 478.00),
(5, 'Lid Broken', '2024-06-22', 'Mengabang Telipot', 'Screenshot 2024-06-05 011338.png', 1, 'Bit Dent', 'No', '2024-06-29', 478.00),
(7, 'Bin Vandalism', '2024-06-29', 'Pasar Payang', 'Slip Peperiksaan  (S202324-II).pdf', 6, 'Sever', 'No', '2024-06-28', 478.00),
(8, 'Broken Bin', '2024-07-04', 'Kuala Nerus', 'updatePic.jpg', 4, 'Bit Dent', 'No', '2024-07-04', 210.00);

-- --------------------------------------------------------

--
-- Table structure for table `garbagetruckmaintenance`
--

CREATE TABLE `garbagetruckmaintenance` (
  `maintenance_id` int(11) NOT NULL,
  `truckid` int(11) DEFAULT NULL,
  `routeid` int(11) DEFAULT NULL,
  `maintenance_date` date DEFAULT NULL,
  `maintenance_type` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `garbagetruckmaintenance`
--

INSERT INTO `garbagetruckmaintenance` (`maintenance_id`, `truckid`, `routeid`, `maintenance_date`, `maintenance_type`, `description`, `cost`) VALUES
(7, 4, 8, '2024-06-18', 'Gas Change', 'Need to change gas', 478.00),
(8, 4, 16, '2024-07-06', 'Engine Oil', 'Hell No', 543.00);

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` int(11) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `latitude`, `longitude`, `timestamp`) VALUES
(1, 5.412789, 103.067932, '2024-06-04 17:55:51'),
(4, 5.412781, 103.067909, '2024-06-04 17:58:13'),
(6, 5.412811, 103.067917, '2024-06-04 18:06:44'),
(7, 5.412814, 103.067917, '2024-06-04 18:06:54'),
(9, 5.412815, 103.067917, '2024-06-04 18:07:14'),
(10, 5.412813, 103.067924, '2024-06-04 18:07:24'),
(11, 5.412812, 103.067924, '2024-06-04 18:07:34'),
(12, 5.412816, 103.067932, '2024-06-04 18:07:44'),
(13, 5.412817, 103.067932, '2024-06-04 18:07:54'),
(14, 5.412813, 103.067932, '2024-06-04 18:08:04'),
(15, 5.412807, 103.067924, '2024-06-04 18:08:14'),
(16, 5.412808, 103.067924, '2024-06-04 18:08:24'),
(17, 5.412805, 103.067924, '2024-06-04 18:08:34'),
(18, 5.412803, 103.067932, '2024-06-04 18:08:44'),
(19, 5.41281, 103.067932, '2024-06-04 18:08:54'),
(20, 5.412814, 103.067924, '2024-06-04 18:09:04'),
(21, 5.412814, 103.067924, '2024-06-04 18:09:14'),
(22, 5.412818, 103.067932, '2024-06-04 18:09:24'),
(23, 5.412822, 103.067932, '2024-06-04 18:09:34'),
(24, 5.412822, 103.06794, '2024-06-04 18:09:44'),
(25, 5.412819, 103.06794, '2024-06-04 18:09:54'),
(26, 5.412816, 103.06794, '2024-06-04 18:10:04'),
(27, 5.412811, 103.067932, '2024-06-04 18:10:14'),
(28, 5.412811, 103.06794, '2024-06-04 18:10:24'),
(29, 5.412816, 103.06794, '2024-06-04 18:10:34'),
(31, 5.412809, 103.067932, '2024-06-04 18:10:54'),
(32, 5.41281, 103.067932, '2024-06-04 18:11:04'),
(33, 5.412811, 103.067932, '2024-06-04 18:11:14'),
(34, 5.412807, 103.067917, '2024-06-04 18:11:24'),
(35, 5.412802, 103.067909, '2024-06-04 18:11:34'),
(36, 5.412799, 103.067902, '2024-06-04 18:11:44'),
(37, 5.412798, 103.067902, '2024-06-04 18:11:54'),
(38, 5.412799, 103.067894, '2024-06-04 18:12:04'),
(39, 5.412797, 103.067894, '2024-06-04 18:12:14'),
(40, 5.412794, 103.067902, '2024-06-04 18:12:24'),
(41, 5.412793, 103.067902, '2024-06-04 18:12:34'),
(42, 5.412795, 103.067902, '2024-06-04 18:12:44'),
(43, 5.412858, 103.067978, '2024-06-05 17:35:59'),
(44, 5.412803, 103.0681, '2024-06-05 17:36:09'),
(45, 5.412821, 103.068176, '2024-06-05 17:38:12'),
(46, 5.412822, 103.068054, '2024-06-05 17:38:42'),
(47, 5.412804, 103.067909, '2024-06-05 17:39:12'),
(48, 5.412794, 103.067863, '2024-06-05 17:39:42'),
(49, 5.412798, 103.067871, '2024-06-05 17:40:12'),
(50, 5.412858, 103.067947, '2024-06-11 07:46:51'),
(52, 5.412854, 103.067932, '2024-06-11 07:48:13'),
(53, 5.412854, 103.067932, '2024-06-11 07:48:43'),
(54, 5.412866, 103.067902, '2024-06-11 07:49:13'),
(55, 5.412845, 103.067932, '2024-06-11 07:49:43'),
(56, 5.412791, 103.067932, '2024-06-25 15:17:53'),
(57, 5.412798, 103.067955, '2024-06-25 15:18:23'),
(58, 5.412811, 103.067978, '2024-06-25 15:18:53'),
(59, 5.412801, 103.067986, '2024-06-25 15:19:23'),
(60, 5.412799, 103.067986, '2024-06-25 15:19:53'),
(61, 5.412799, 103.067986, '2024-06-25 15:20:23'),
(62, 5.412804, 103.06794, '2024-07-01 06:52:12'),
(63, 5.412804, 103.06794, '2024-07-01 06:52:42'),
(64, 5.412804, 103.06794, '2024-07-01 06:53:12'),
(65, 5.412804, 103.06794, '2024-07-01 06:53:42'),
(66, 5.412804, 103.06794, '2024-07-01 06:54:12'),
(67, 5.412804, 103.06794, '2024-07-01 06:54:42'),
(68, 5.412804, 103.06794, '2024-07-01 06:55:12'),
(69, 5.412804, 103.06794, '2024-07-01 06:55:42'),
(70, 5.412804, 103.06794, '2024-07-01 06:56:12'),
(71, 5.412804, 103.06794, '2024-07-01 06:56:42'),
(72, 5.412804, 103.06794, '2024-07-01 06:57:12'),
(73, 5.412804, 103.06794, '2024-07-01 06:57:42'),
(74, 5.412804, 103.06794, '2024-07-01 06:58:12'),
(75, 5.412804, 103.06794, '2024-07-01 06:58:42'),
(76, 5.412804, 103.06794, '2024-07-01 06:59:12'),
(77, 5.412804, 103.06794, '2024-07-01 06:59:42'),
(78, 5.412804, 103.06794, '2024-07-01 07:00:12'),
(79, 5.412804, 103.06794, '2024-07-01 07:00:42'),
(80, 5.412804, 103.06794, '2024-07-01 07:01:12'),
(81, 5.412804, 103.06794, '2024-07-01 07:01:42'),
(82, 5.412804, 103.06794, '2024-07-01 07:02:12'),
(83, 5.412804, 103.06794, '2024-07-01 07:02:42'),
(84, 5.412804, 103.06794, '2024-07-01 07:03:12'),
(85, 5.412804, 103.06794, '2024-07-01 07:03:42'),
(86, 5.412804, 103.06794, '2024-07-01 07:04:12'),
(87, 5.412804, 103.06794, '2024-07-01 07:04:42'),
(89, 5.412804, 103.06794, '2024-07-01 07:05:42'),
(95, 5.412804, 103.06794, '2024-07-01 07:08:42'),
(98, 5.412804, 103.06794, '2024-07-01 07:10:12'),
(99, 5.412804, 103.06794, '2024-07-01 07:10:42'),
(100, 5.412804, 103.06794, '2024-07-01 07:11:12'),
(102, 5.412855, 103.067917, '2024-07-02 00:21:59'),
(103, 5.412848, 103.067902, '2024-07-02 00:22:29'),
(104, 5.412849, 103.067894, '2024-07-02 00:22:59'),
(105, 5.412852, 103.06794, '2024-07-02 00:23:29'),
(106, 5.412845, 103.067963, '2024-07-02 00:23:59'),
(107, 5.412848, 103.067963, '2024-07-02 00:24:29'),
(108, 5.412851, 103.067963, '2024-07-02 00:24:59'),
(109, 5.412845, 103.067924, '2024-07-02 00:25:29'),
(110, 5.412838, 103.067902, '2024-07-02 00:25:59'),
(111, 5.412841, 103.067894, '2024-07-02 00:26:29'),
(112, 5.412848, 103.067909, '2024-07-02 00:26:59'),
(113, 5.412856, 103.067932, '2024-07-02 00:27:29'),
(114, 5.412854, 103.067963, '2024-07-02 00:27:59'),
(115, 5.412842, 103.067986, '2024-07-02 00:28:29'),
(116, 5.412831, 103.067986, '2024-07-02 00:28:59'),
(117, 5.412817, 103.067947, '2024-07-02 00:29:29'),
(118, 5.412804, 103.067894, '2024-07-02 00:29:59'),
(119, 5.410658, 103.088783, '2024-07-03 01:45:20'),
(120, 5.410673, 103.088791, '2024-07-03 01:45:50'),
(121, 5.41069, 103.088814, '2024-07-03 01:46:20'),
(122, 5.410693, 103.088837, '2024-07-03 01:46:50'),
(123, 5.410674, 103.088829, '2024-07-03 01:47:20'),
(124, 5.410753, 103.088814, '2024-07-03 01:47:50'),
(125, 5.410705, 103.088829, '2024-07-03 01:48:20'),
(126, 5.410672, 103.08886, '2024-07-03 01:48:50'),
(127, 5.410686, 103.088814, '2024-07-03 01:49:20'),
(128, 5.410696, 103.088776, '2024-07-03 01:49:50'),
(129, 5.410702, 103.088783, '2024-07-03 01:50:20'),
(130, 5.410591, 103.08886, '2024-07-03 03:28:08'),
(131, 5.410623, 103.088806, '2024-07-03 03:28:38'),
(132, 5.410553, 103.088928, '2024-07-03 03:29:08'),
(133, 5.410652, 103.088936, '2024-07-03 03:29:38'),
(134, 5.410596, 103.088997, '2024-07-03 03:30:08'),
(135, 5.410718, 103.088936, '2024-07-03 03:30:38'),
(136, 5.410743, 103.088898, '2024-07-03 03:31:08'),
(137, 5.41075, 103.08886, '2024-07-03 03:31:38'),
(138, 5.410711, 103.088791, '2024-07-03 03:32:08'),
(139, 5.410705, 103.088783, '2024-07-03 03:32:38'),
(140, 5.410667, 103.088821, '2024-07-03 04:37:29'),
(141, 5.410588, 103.088791, '2024-07-03 04:37:59'),
(142, 5.410609, 103.088745, '2024-07-03 04:38:29'),
(143, 5.410631, 103.08876, '2024-07-03 04:38:59'),
(144, 5.410644, 103.088768, '2024-07-03 04:39:29'),
(145, 5.410635, 103.088791, '2024-07-03 04:39:59'),
(146, 5.410629, 103.088791, '2024-07-03 04:40:29'),
(147, 5.410609, 103.088791, '2024-07-03 04:40:59'),
(148, 5.410594, 103.088783, '2024-07-03 04:41:29'),
(149, 5.410604, 103.088791, '2024-07-03 04:42:02'),
(150, 5.410621, 103.088806, '2024-07-03 04:42:32'),
(151, 5.410637, 103.088806, '2024-07-03 04:42:59'),
(152, 5.410632, 103.088806, '2024-07-03 04:43:29'),
(153, 5.410627, 103.088799, '2024-07-03 04:43:59'),
(154, 5.41067, 103.088799, '2024-07-03 04:44:29'),
(155, 5.41067, 103.088814, '2024-07-03 04:44:59'),
(156, 5.410684, 103.088844, '2024-07-03 04:45:29'),
(157, 5.410704, 103.08886, '2024-07-03 04:45:59'),
(158, 5.410699, 103.08886, '2024-07-03 04:46:29'),
(159, 5.410681, 103.088844, '2024-07-03 04:46:59'),
(160, 5.410663, 103.088791, '2024-07-03 04:47:29'),
(161, 5.410658, 103.088768, '2024-07-03 04:47:59'),
(162, 5.410663, 103.088768, '2024-07-03 04:48:29'),
(163, 5.410657, 103.088783, '2024-07-03 04:48:59'),
(164, 5.410673, 103.088799, '2024-07-03 04:49:29');

-- --------------------------------------------------------

--
-- Table structure for table `managers`
--

CREATE TABLE `managers` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `managers`
--

INSERT INTO `managers` (`id`, `name`, `email`, `password`, `phone`, `address`, `created_at`) VALUES
(5, 'Syahmi', 'syahmi@gmail.com', 'syahmi1234', '019-389483', 'Syah Alam', '2024-01-22 09:33:19'),
(11, 'Atif Afifi', 'atif@gmail.com', 'atif1234', '6012-3408344', 'Gurun', '2024-06-26 23:08:59'),
(12, 'Labi', 'labi@gmail.com', '$2y$10$YnEDvovyu9fhStLZ4TkV3ulSLPN4fRvmYK3t1YYCVP7B45GRLJ98m', '6012-3408344', 'Rawang', '2024-06-27 00:31:32'),
(13, 'Ahmad Mukhlis', 'mukhlis@gmail.com', 'mukhlis1234', '019-35846892', 'Bertam Perdana', '2024-06-27 00:35:06'),
(14, 'Abu Bakar', 'abubakar@gmail.com', '$2y$10$ARW92t.cSCKASThcSbqXMO2YZ3xi8ee45VcPwkJoI9WJa92rvqfBm', '01939034', 'Kuala Nerus', '2024-06-29 01:05:41'),
(15, 'Admin', 'admin@gmail.com', 'admin', '018-49479043', 'Hulu Langat', '2024-06-30 13:55:45'),
(16, 'Zulhilmi Rosli', 'zulhilmi@gmail.com', '$2y$10$NXtcwUO52UpxHR21YJtZR.k.WFaa7xrwkyfOEBC7Cm06VHGW/H416', '0197965630', 'Sungai Petani', '2024-07-03 10:16:24'),
(17, 'Baihaqi ', 'baihaqi@gmail.com', '$2y$10$5FwSbW/BAdJOFe8KExQ4B.LCXYdb0iUPvUoCtNO.r4YvS.WTc5HRu', '6012-3408344', 'Kulai', '2024-07-03 10:17:03');

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

CREATE TABLE `routes` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `no_plate` varchar(50) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `chosen` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `routes`
--

INSERT INTO `routes` (`id`, `name`, `no_plate`, `model`, `location`, `status`, `start_time`, `end_time`, `chosen`) VALUES
(1, 'Padang Nanas', 'PKX3483', 'Model B', 'https://www.google.com/maps/embed/v1/directions?key=AIzaSyAmu5bO1pXz3MiEUfB5o3PwehgRZUWZ9Mc&origin=Kuala+Terengganu,+Terengganu&destination=Kampung+Gong+Badak,+21300+Kuala+Terengganu,+Terengganu,+Malaysia&waypoints=Bandar+baru+Kuala+nerus,+Kuala+Terenggan', 'available', '19:03:00', '10:09:00', 1),
(3, 'Setiu', 'KEM383', 'Model C', 'https://www.google.com/maps/dir/Kuala+Terengganu,+Terengganu,+Malaysia/UMT+Setiu+Wetland+Stesen+Penyelidikan+Tanah+Bencah+UMT,+Batu,,+Kampung+Gong+Terap,+Setiu,+Terengganu,+Malaysia/Kampung+Gong+Badak,+21300+Kuala+Terengganu,+Terengganu,+Malaysia/@5.49569', 'available', '16:28:00', '04:30:00', 0),
(4, 'Kuala Nerus', 'KEK2893', 'Mitsubishi', 'https://www.google.com/maps/embed/v1/directions?key=AIzaSyAmu5bO1pXz3MiEUfB5o3PwehgRZUWZ9Mc&origin=Kuala+Terengganu,+Terengganu,+Malaysia&destination=Kampung+Gong+Badak,+21300+Kuala+Terengganu,+Terengganu,+Malaysia&waypoints=Lot+6820,+PETRONAS+Batu+Rakit,', 'available', '16:31:00', '16:31:00', 0),
(8, 'Mengabang Telipot', 'WLQ7392', 'Model B', 'https://www.google.com/maps/embed/v1/directions?key=AIzaSyAmu5bO1pXz3MiEUfB5o3PwehgRZUWZ9Mc&origin=Kuala+Terengganu,+Terengganu,+Malaysia&destination=Kampung+Gong+Badak,+21300+Kuala+Terengganu,+Terengganu,+Malaysia&waypoints=Lot+6820,+PETRONAS+Batu+Rakit,', 'available', '11:59:00', '23:01:00', 0),
(12, 'Gong Pok Jin', 'WET4692', 'Model A', 'https://www.google.com/maps/embed/v1/directions?key=AIzaSyAmu5bO1pXz3MiEUfB5o3PwehgRZUWZ9Mc&origin=Kuala+Terengganu,+Terengganu,+Malaysia&destination=Kampung+Gong+Badak,+21300+Kuala+Terengganu,+Terengganu,+Malaysia&waypoints=UMT+Setiu+Wetland+Stesen+Penye', 'available', '03:48:00', '17:48:00', 0),
(13, 'Marang', 'TEC6394', 'Mitsubishi', 'https://www.google.com/maps/embed/v1/directions?key=AIzaSyAmu5bO1pXz3MiEUfB5o3PwehgRZUWZ9Mc&origin=Kuala+Terengganu,+Terengganu,+Malaysia&destination=Kampung+Gong+Badak,+21300+Kuala+Terengganu,+Terengganu,+Malaysia&waypoints=KFCGongBadak+GongBadak+PayaBun', 'available', '15:42:00', '20:42:00', 0),
(14, 'Tok Jembal', 'HTM7943', 'Model B', 'https://www.google.com/maps/embed/v1/directions?key=AIzaSyAmu5bO1pXz3MiEUfB5o3PwehgRZUWZ9Mc&origin=Kuala+Terengganu,+Terengganu,+Malaysia&destination=Kampung+Gong+Badak,+21300+Kuala+Terengganu,+Terengganu,+Malaysia&waypoints=UNISZA+GongBadak+KTCC+Stesen+P', 'available', '10:50:00', '04:50:00', 0),
(15, 'Taman Semarak', 'KER3496', 'Model C', 'https://www.google.com/maps/embed/v1/directions?key=AIzaSyAmu5bO1pXz3MiEUfB5o3PwehgRZUWZ9Mc&origin=UMT,+Kuala+Terengganu,+Terengganu&destination=UMT,+Kuala+Terengganu,+Terengganu&waypoints=Kuala+Terengganu,+Terengganu,+Malaysia|Taman+Semarak,+Kuala+Tereng', 'available', '11:45:00', '04:45:00', 0),
(16, 'Pasar Payang', 'QRT0934', 'Model B', 'https://www.google.com/maps/embed/v1/directions?key=AIzaSyAmu5bO1pXz3MiEUfB5o3PwehgRZUWZ9Mc&origin=Kuala+Terengganu,+Terengganu&destination=Pasar+Payang,+Jalan+Sultan+Zainal+Abidin,+Kampung+Tanjung+Kapur,+Kuala+Terengganu,+Terengganu&waypoints=Bukit+Maras', 'available', '17:01:00', '20:13:00', 1),
(17, 'Bukit Besar', 'PKQ9834', 'Model C', 'https://www.google.com/maps/embed/v1/directions?key=AIzaSyAmu5bO1pXz3MiEUfB5o3PwehgRZUWZ9Mc&origin=Bukit+Besar,+Terengganu&destination=Bukit+Besar,+Terengganu&waypoints=Pantai+Pandak,+Kuala+Terengganu,+Terengganu|Masjid+Tengku+Tengah+Zaharah,+Jalan+Batu+B', 'available', '18:04:00', '13:04:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `trucks`
--

CREATE TABLE `trucks` (
  `truckid` int(11) NOT NULL,
  `routeid` int(11) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `licensePlate` varchar(255) DEFAULT NULL,
  `driver_name` varchar(100) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trucks`
--

INSERT INTO `trucks` (`truckid`, `routeid`, `model`, `licensePlate`, `driver_name`, `capacity`) VALUES
(1, 4, 'Vector', 'KDX6391', 'Abdul', 10),
(2, 3, 'Lexus', 'PL2933', 'Abdul', 12),
(4, 1, 'Mitsubishi', 'KDX6391', 'Abdul', 144),
(6, 8, 'Mitsubishi', 'LLI0944', 'Abu', 901);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(60) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `phone`, `address`, `created_at`) VALUES
(19, 'Naufal Bin Rashidi', 'naufal@gmail.com', 'nopal1234', '6017-378924', 'Alor Setar', '2024-01-22 00:11:58'),
(22, 'Fakhrul Radzi', 'fakhrul@gmail.com', '$2y$10$4FRzcGqmf', '016-3578393', 'Jelutong', '2024-06-27 00:40:45'),
(30, 'Akmal Hakim Aziz', 'akmal@gmail.com', '$2y$10$gTHnVyli/nqYnzVOL3eJI.97b85Zgq2oPJ9rDA8wSoJG684DfGbJO', '6012-3408346', 'Kampar', '2024-06-29 19:22:05'),
(32, 'admin1', 'admin1@gmail.com', '$2y$10$cUMfTdnIHuliBm5Vgwj9peozUX1JB7PndvePVQzvqpQzA.XcUSKSG', '0197965630', 'Taiping', '2024-06-30 14:01:13'),
(33, 'tester', 'tester@gmail.com', '$2y$10$wnGKpod/jmauqNWzqgPVfupaZSgtOp8KvG9TLmwiao24EvPIKryrO', '0193793356', 'Taiping', '2024-07-03 10:19:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `checkin`
--
ALTER TABLE `checkin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `plate_number` (`plate_number`),
  ADD KEY `driver_id` (`driver_id`),
  ADD KEY `route_id` (`route_id`);

--
-- Indexes for table `damagefrm`
--
ALTER TABLE `damagefrm`
  ADD PRIMARY KEY (`id`),
  ADD KEY `truckid` (`truckid`);

--
-- Indexes for table `garbagetruckmaintenance`
--
ALTER TABLE `garbagetruckmaintenance`
  ADD PRIMARY KEY (`maintenance_id`),
  ADD KEY `truckid` (`truckid`),
  ADD KEY `routeid` (`routeid`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `managers`
--
ALTER TABLE `managers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `routes`
--
ALTER TABLE `routes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `no_plate` (`no_plate`);

--
-- Indexes for table `trucks`
--
ALTER TABLE `trucks`
  ADD PRIMARY KEY (`truckid`),
  ADD KEY `routeid` (`routeid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `checkin`
--
ALTER TABLE `checkin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `damagefrm`
--
ALTER TABLE `damagefrm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `garbagetruckmaintenance`
--
ALTER TABLE `garbagetruckmaintenance`
  MODIFY `maintenance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=165;

--
-- AUTO_INCREMENT for table `managers`
--
ALTER TABLE `managers`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `routes`
--
ALTER TABLE `routes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `trucks`
--
ALTER TABLE `trucks`
  MODIFY `truckid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `checkin`
--
ALTER TABLE `checkin`
  ADD CONSTRAINT `checkin_ibfk_1` FOREIGN KEY (`plate_number`) REFERENCES `routes` (`no_plate`),
  ADD CONSTRAINT `checkin_ibfk_2` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`);

--
-- Constraints for table `damagefrm`
--
ALTER TABLE `damagefrm`
  ADD CONSTRAINT `damagefrm_ibfk_1` FOREIGN KEY (`truckid`) REFERENCES `trucks` (`truckid`);

--
-- Constraints for table `garbagetruckmaintenance`
--
ALTER TABLE `garbagetruckmaintenance`
  ADD CONSTRAINT `garbagetruckmaintenance_ibfk_1` FOREIGN KEY (`truckid`) REFERENCES `trucks` (`truckid`),
  ADD CONSTRAINT `garbagetruckmaintenance_ibfk_2` FOREIGN KEY (`routeid`) REFERENCES `routes` (`id`);

--
-- Constraints for table `trucks`
--
ALTER TABLE `trucks`
  ADD CONSTRAINT `trucks_ibfk_1` FOREIGN KEY (`routeid`) REFERENCES `routes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
