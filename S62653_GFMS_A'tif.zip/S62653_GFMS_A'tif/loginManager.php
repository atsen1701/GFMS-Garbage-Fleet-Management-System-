<?php
session_start(); // Start the session

// Database connection configuration
$servername = "localhost";
$username = "root";
$password = "";
$database = "gfmsu";

// Create connection
$connection = new mysqli($servername, $username, $password, $database);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize and validate input
    $email = mysqli_real_escape_string($connection, $_POST['email']);
    $password = mysqli_real_escape_string($connection, $_POST['password']);

    // SQL query to fetch user data based on email
    $sql = "SELECT * FROM managers WHERE email='$email'";
    $result = $connection->query($sql);

    if ($result->num_rows == 1) {
        // User found, check password
        $row = $result->fetch_assoc();
        $hashed_password = $row['password'];

        // Debugging output
        echo "Hashed password from DB: " . $hashed_password . "<br>";
        echo "Entered password: " . $password . "<br>";

        // Verify hashed password
        if (password_verify($password, $hashed_password)) {
            // Password is correct, set session variables or redirect to authenticated area
            $_SESSION['user_id'] = $row['id']; // Store user ID in session for future use
            $_SESSION['email'] = $row['email']; // Store email in session
            header("Location: MngDash.php");
            exit();
        } else {
            // Password is incorrect
            echo "Invalid password"; // Debugging output
            //header("Location: index.php?error=Invalid password");
            exit();
        }
    } else {
        // No user found with that email
        echo "User not found"; // Debugging output
        //header("Location: index.php?error=User not found");
        exit();
    }
}

// Close connection
$connection->close();
?>
