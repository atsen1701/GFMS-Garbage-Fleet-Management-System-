<?php
session_start(); // Start the session

// Database connection configuration
$servername = "localhost";
$username = "root";
$password = "";
$database = "gfmsu";

// Create connection
$connection = new mysqli($servername, $username, $password, $database);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Initialize error and success messages
$errorMessage = '';
$successMessage = '';
$profileUpdated = false; // Add this flag

// Fetch logged-in user's data from database
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM managers WHERE id='$user_id'";
$result = $connection->query($sql);

if ($result->num_rows == 1) {
    // User found, fetch user details
    $row = $result->fetch_assoc();
    $id = $row['id']; // Added to retrieve user's ID for the form
    $name = $row['name'];
    $email = $row['email'];
    $phone = $row['phone'];
    $address = $row['address'];

    // Handle form submission for editing user details
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Sanitize and validate input (if needed)
        $name = mysqli_real_escape_string($connection, $_POST['name']);
        $email = mysqli_real_escape_string($connection, $_POST['email']);
        $phone = mysqli_real_escape_string($connection, $_POST['phone']);
        $address = mysqli_real_escape_string($connection, $_POST['address']);
        $password = mysqli_real_escape_string($connection, $_POST['password']);

        // Update query
        $sql_update = "UPDATE managers SET name='$name', email='$email', phone='$phone', address='$address' WHERE id='$user_id'";
        if ($connection->query($sql_update) === TRUE) {
            // Update successful
            $profileUpdated = true; // Set the flag
            $successMessage = "Profile updated successfully";
            // Update session variables if needed
            $_SESSION['name'] = $name;
            $_SESSION['email'] = $email;
            $_SESSION['phone'] = $phone;
            $_SESSION['address'] = $address;
        } else {
            // Update failed
            $errorMessage = "Error updating profile: " . $connection->error;
        }
    }
} else {
    // User not found (should not happen if user is logged in)
    header("Location: index.php?error=User not found");
    exit();
}

// Close connection
$connection->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>SB Admin 2 - Edit Profile</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-primary">
    <div class="container">
        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <div class="row">
                    <div class="col-lg-5 d-none d-lg-block bg-register-image"></div>
                    <div class="col-lg-7">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Edit Profile</h1>
                            </div>
                            <?php if (!empty($errorMessage)): ?>
                                <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
                            <?php endif; ?>
                            <?php if (!empty($successMessage)): ?>
                                <div class="alert alert-success"><?php echo $successMessage; ?></div>
                            <?php endif; ?>
                            <form class="user" method="post" action="">
                                <input type="hidden" name="id" value="<?php echo $id; ?>">
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="text" class="form-control form-control-user" name="name" placeholder="Name" value="<?php echo $name; ?>">
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="email" class="form-control form-control-user" name="email" placeholder="Email" value="<?php echo $email; ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control form-control-user" name="password" placeholder="Password" value="<?php echo $password; ?>">
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="text" class="form-control form-control-user" name="phone" placeholder="Phone" value="<?php echo $phone; ?>">
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control form-control-user" name="address" placeholder="Address" value="<?php echo $address; ?>">
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary btn-user btn-block">
                                    Update Managers
                                </button>
                            </form>
                            <hr>
                     
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            <?php if ($profileUpdated): ?>
                alert('Profile updated successfully');
                setTimeout(function() {
                    window.location.href = 'MngDash.php';
                }, 2000); // Redirect after 2 seconds
            <?php endif; ?>
        });
    </script>
</body>
</html>
