<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gfmsu";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT COUNT(*) as total FROM routes";
$result = $conn->query($sql);

$data = $result->fetch_assoc();
header('Content-Type: application/json');
echo json_encode($data);

$conn->close();
?>
