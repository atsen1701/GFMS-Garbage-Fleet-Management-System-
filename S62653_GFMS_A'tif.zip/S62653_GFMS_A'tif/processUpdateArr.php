<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    // Validate and sanitize inputs as needed
    $id = $_POST['id']; // Assuming you have an 'id' field in your form

    // Retrieve other form data
    $name = $_POST['name'];
    $plate_number = $_POST['plate_number'];
    $status = $_POST['status'];
    $arrival_time = $_POST['arrival_time'];
    $checkout_time = $_POST['checkout_time'];
    $driver_id = $_POST['driver_id'];
    $route_id = $_POST['route_id'];
    $remarks = $_POST['remarks'];

    // Prepare the SQL statement
    $sql = "UPDATE checkin SET name=?, plate_number=?, status=?, arrival_time=?, checkout_time=?, driver_id=?, route_id=?, remarks=? WHERE id=?";
    $stmt = $pdo->prepare($sql);

    try {
        $stmt->execute([$name, $plate_number, $status, $arrival_time, $checkout_time, $driver_id, $route_id, $remarks, $id]);

        // Redirect to success page or previous page
        header("Location: idxArrival.php");
        exit();
    } catch (PDOException $e) {
        // Handle update failure
        echo "Error updating record: " . $e->getMessage();
    }
} else {
    // Redirect to error page or handle unauthorized access
    header("Location: error.php");
    exit();
}
?>
