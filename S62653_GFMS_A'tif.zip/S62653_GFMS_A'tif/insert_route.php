<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $no_plate = $_POST['no_plate'];
    $model = $_POST['model'];
    $location = $_POST['location'];
    $status = $_POST['status'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];

    $sql = "INSERT INTO routes (name, no_plate, model, location, status, start_time, end_time) 
            VALUES (:name, :no_plate, :model, :location, :status, :start_time, :end_time)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'name' => $name,
        'no_plate' => $no_plate,
        'model' => $model,
        'location' => $location,
        'status' => $status,
        'start_time' => $start_time,
        'end_time' => $end_time,
    ]);

    header('Location: idxRoutes.php');
    exit;
}
?>
