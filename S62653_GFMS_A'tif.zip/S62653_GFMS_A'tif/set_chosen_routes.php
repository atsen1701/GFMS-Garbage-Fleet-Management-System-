<?php
session_start();
include 'db.php'; // Include your database connection script

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['route_id'])) {
    $route_id = $_POST['route_id'];

    // Update the chosen status in the database
    $sql = "UPDATE routes SET chosen = 1 WHERE id = ?";
    $stmt = $pdo->prepare($sql);

    if ($stmt->execute([$route_id])) {
        // Retrieve the selected route details and store in session for TrckDash.php
        $sql = "SELECT * FROM routes WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        if ($stmt->execute([$route_id])) {
            $route = $stmt->fetch(PDO::FETCH_ASSOC);
            $_SESSION['selectedRoute'] = $route;
            $response['success'] = true;
        } else {
            $response['success'] = false;
            $response['message'] = "Failed to fetch route details";
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Failed to update chosen route";
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request";
}

header('Content-Type: application/json');
echo json_encode($response);
?>
