<?php
// Ensure that the truckid parameter is set and not empty
if (isset($_GET['truckid']) && !empty($_GET['truckid'])) {
    // Database connection details
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "gfmsu";

    // Create connection
    $connection = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($connection->connect_error) {
        die("Connection failed: " . $connection->connect_error);
    }

    // Prepare SQL statement to delete the truck record
    $truckid = $_GET['truckid'];
    $sql = "DELETE FROM trucks WHERE truckid = $truckid";

    // Execute the delete query
    if ($connection->query($sql) === TRUE) {
        echo "Truck record deleted successfully.";
    } else {
        echo "Error deleting record: " . $connection->error;
    }

    // Close connection
    $connection->close();
} else {
    echo "Invalid truckid parameter.";
}
// Redirect to the maintenance list page after deletion
header("Location: idxTrucks.php");
exit()
?>
