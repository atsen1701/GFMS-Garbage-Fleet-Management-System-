<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gfmsu";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT latitude, longitude FROM locations ORDER BY timestamp DESC LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  echo json_encode(['latitude' => $row['latitude'], 'longitude' => $row['longitude']]);
} else {
  echo json_encode(['latitude' => null, 'longitude' => null]);
}

$conn->close();
?>
