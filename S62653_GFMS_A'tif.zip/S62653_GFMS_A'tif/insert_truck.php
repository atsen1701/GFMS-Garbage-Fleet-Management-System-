<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $routeid = $_POST['routeid'];
    $model = $_POST['model'];
    $licensePlate = $_POST['licensePlate'];
    $driver_name = $_POST['driver_name'];
    $capacity = $_POST['capacity'];

    $sql = "INSERT INTO trucks (routeid, model, licensePlate, driver_name, capacity) 
            VALUES (:routeid, :model, :licensePlate, :driver_name, :capacity)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'routeid' => $routeid,
        'model' => $model,
        'licensePlate' => $licensePlate,
        'driver_name' => $driver_name,
        'capacity' => $capacity,
    ]);

    header('Location: idxTrucks.php');
    exit;
}
?>
