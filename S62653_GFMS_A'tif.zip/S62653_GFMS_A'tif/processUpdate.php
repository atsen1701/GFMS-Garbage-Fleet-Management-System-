<?php
include 'db.php';

if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $description = $_POST['description'];
    $date = $_POST['date'];
    $location = $_POST['location'];
    $truckid = $_POST['truckid'];
    $severity = $_POST['severity'];
    $repair_status = $_POST['repair_status'];
    $repair_date = $_POST['repair_date'];
    $cost = $_POST['cost'];

    $image = "";
    if (!empty($_FILES['image']['name'])) {
        $image = basename($_FILES['image']['name']);
        $target_dir = "C:/xampp/htdocs/TestCombine/uploads/";
        $target_file = $target_dir . $image;
        move_uploaded_file($_FILES['image']['tmp_name'], $target_file);
    } else {
        $image = $_POST['existing_image'];
    }

    // Prepare the SQL statement
    $sql = "UPDATE damagefrm SET description=?, date=?, location=?, truckid=?, severity=?, repair_status=?, repair_date=?, cost=?, image=? WHERE id=?";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$description, $date, $location, $truckid, $severity, $repair_status, $repair_date, $cost, $image, $id]);

        echo "Record updated successfully. Redirecting you back to the form...";
        header('refresh:3; url=idxDamage.php');
        exit();
    } catch (PDOException $e) {
        echo "Error updating record: " . $e->getMessage();
    }
}
?>
