<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $truckid = $_POST['truckid'];
    $routeid = $_POST['routeid'];
    $maintenance_date = $_POST['maintenance_date'];
    $maintenance_type = $_POST['maintenance_type'];
    $description = $_POST['description'];
    $cost = $_POST['cost'];

    $sql = "INSERT INTO garbagetruckmaintenance (truckid, routeid, maintenance_date, maintenance_type, description, cost) 
            VALUES (:truckid, :routeid, :maintenance_date, :maintenance_type, :description, :cost)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'truckid' => $truckid,
        'routeid' => $routeid,
        'maintenance_date' => $maintenance_date,
        'maintenance_type' => $maintenance_type,
        'description' => $description,
        'cost' => $cost,
    ]);

    header('Location: idxMaintenance.php');
    exit;
}
?>
