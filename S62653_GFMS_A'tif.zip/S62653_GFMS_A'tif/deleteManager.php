<?php
if(isset($_GET["id"])){
    $id = $_GET["id"];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "gfmsu";
    $connection=new mysqli($servername, $username, $password, $database);

    $sql = "DELETE FROM managers WHERE id=$id";
    $connection->query($sql);
}  
header("location: /TestCombine/idxManagers.php");
 exit;
?>