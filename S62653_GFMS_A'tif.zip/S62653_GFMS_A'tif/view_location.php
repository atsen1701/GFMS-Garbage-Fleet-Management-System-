<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Selected Route Details</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .route-details {
            margin-top: 20px;
        }

        .route-details h3 {
            margin-bottom: 15px;
        }

        .route-details p {
            margin-bottom: 5px;
        }

        #map-frame {
            width: 100%;
            height: 400px; /* Adjust height as needed */
            border: 0;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="route-details">
            <h3>Selected Route Details</h3>
            <div id="route-info"></div>
            <iframe id="map-frame" allowfullscreen loading="lazy" referrerpolicy="no-referrer-when-downgrade">
            </iframe>
            <a href="TrckDash.php" class="btn btn-primary mt-3">Back to Dashboard</a>
        </div>
    </div>

    <!-- Include Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Include jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        // Function to initialize the map and display route details
        function initMap() {
            // Example map initialization
            var mapUrl = "https://www.google.com/maps/embed/v1/directions?key=AIzaSyAmu5bO1pXz3MiEUfB5o3PwehgRZUWZ9Mc&origin=Kuala+Terengganu,+Terengganu,+Malaysia&destination=Kampung+Gong+Badak,+21300+Kuala+Terengganu,+Terengganu,+Malaysia&waypoints=UMT+Setiu+Wetland+Stesen+Penye";
            
            // Update the iframe src attribute to load the map
            document.getElementById('map-frame').src = mapUrl;

            // Display route details (example)
            var routeInfo = `<div class="card">
                                <div class="card-body">
                                    <p><strong>Origin:</strong> Kuala Terengganu, Terengganu, Malaysia</p>
                                    <p><strong>Destination:</strong> Kampung Gong Badak, 21300 Kuala Terengganu, Terengganu, Malaysia</p>
                                    <p><strong>Waypoints:</strong> UMT Setiu Wetland Stesen Penye</p>
                                </div>
                             </div>`;
            document.getElementById('route-info').innerHTML = routeInfo;
        }

        // Initialize map on page load
        window.onload = initMap;
    </script>
</body>

</html>
