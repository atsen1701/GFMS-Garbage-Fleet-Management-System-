<?php
include 'db.php';

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    try {
        // Prepare the SQL statement
        $sql = "DELETE FROM damagefrm WHERE id=?";
        $stmt = $pdo->prepare($sql);

        // Execute the prepared statement
        $stmt->execute([$id]);

        // Check if the deletion was successful
        if ($stmt->rowCount() > 0) {
            echo "Record deleted successfully. Redirecting you back to the form...";
            header('refresh:3; url=idxDamage.php');
            exit();
        } else {
            echo "Record with ID $id not found.";
        }
    } catch (PDOException $e) {
        // Handle delete failure
        echo "Error deleting record: " . $e->getMessage();
    }
}
?>
