<?php
// Include database connection
include 'db.php';  // Adjust the path as necessary

// Check if route_id is provided
if (isset($_POST['route_id'])) {
    $route_id = $_POST['route_id'];

    try {
        // Query to fetch plate numbers associated with the selected route
        $stmt = $pdo->prepare("SELECT DISTINCT no_plate FROM routes WHERE id = :route_id");
        $stmt->execute(['route_id' => $route_id]);
        $plate_numbers = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Return JSON response
        header('Content-Type: application/json');
        echo json_encode($plate_numbers);
    } catch (PDOException $e) {
        // Handle database error
        die("Error fetching plate numbers: " . $e->getMessage());
    }
} else {
    // Handle case where route_id is not provided
    echo json_encode([]);  // Return empty array if route_id is missing
}
?>
