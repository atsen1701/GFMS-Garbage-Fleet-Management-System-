<?php
include 'db.php'; // Ensure your database connection script is included

function get_routes_status() {
    global $pdo; // Assuming $pdo is your PDO database connection object

    try {
        $stmt = $pdo->query("SELECT status, COUNT(*) AS count FROM routes GROUP BY status");
        $statusCounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $statusCounts;
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        return false;
    }
}
?>
