<?php
// Database credentials (replace with your actual database details)
$db_host = 'localhost';
$db_name = 'gfmsu';
$db_user = 'root';
$db_pass = '';

// Attempt to connect to the database
try {
    $pdo = new PDO("mysql:host={$db_host};dbname={$db_name}", $db_user, $db_pass);
    // Set PDO to throw exceptions on error
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    // Retrieve maintenance details based on the ID passed through URL
    $maintenance_id = $_GET['id'];
    
    // Example query to fetch maintenance details
    $query = "SELECT * FROM garbagetruckmaintenance WHERE maintenance_id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$maintenance_id]);
    $maintenance = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$maintenance) {
        // Handle case where maintenance record with given ID does not exist
        die("Maintenance record not found.");
    }
} elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    // Handle form submission for updating maintenance record
    
    // Retrieve form data
    $maintenance_id = $_POST['maintenance_id'];
    $truckid = $_POST['truckid'];
    $routeid = $_POST['routeid'];
    $maintenance_date = $_POST['maintenance_date'];
    $maintenance_type = $_POST['maintenance_type'];
    $description = $_POST['description'];
    $cost = $_POST['cost'];
    
    // Example query to update maintenance record
    $query = "UPDATE garbagetruckmaintenance SET truckid = ?, routeid = ?, maintenance_date = ?, maintenance_type = ?, description = ?, cost = ? WHERE maintenance_id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$truckid, $routeid, $maintenance_date, $maintenance_type, $description, $cost, $maintenance_id]);
    
    // Check if update was successful
    $edit_successful = $stmt->rowCount() > 0;
    
    // Redirect back to the original page
    $return_url = isset($_GET['return_url']) ? $_GET['return_url'] : 'idxMaintenance.php'; // default to tables.php if return_url not set
    header("Location: $return_url");
    exit();
} else {
    // Handle invalid request method or missing ID
    die("Invalid request.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Maintenance Record</title>
    <!-- Bootstrap core CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles -->
    <style>
        body {
            background-color: #f8f9fc; /* Light blue background */
            padding: 20px; /* Padding for content */
        }
        form {
            background-color: #ffffff; /* White background for form */
            padding: 20px; /* Padding inside form */
            border-radius: 8px; /* Rounded corners */
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); /* Shadow for card effect */
        }
        label {
            font-weight: bold; /* Bold labels */
        }
        input[type="text"], input[type="date"], textarea {
            width: 100%; /* Full width input fields */
            padding: 10px; /* Padding for input fields */
            margin-bottom: 15px; /* Spacing between fields */
            border: 1px solid #ccc; /* Light border */
            border-radius: 4px; /* Rounded corners */
        }
        input[type="submit"] {
            background-color: #007bff; /* Bootstrap primary color for submit button */
            color: #fff; /* White text */
            border: none; /* No border */
            padding: 10px 20px; /* Padding for button */
            cursor: pointer; /* Pointer cursor */
            border-radius: 4px; /* Rounded corners */
        }
        input[type="submit"]:hover {
            background-color: #0056b3; /* Darker shade of blue on hover */
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Edit Maintenance Record</div>

                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="maintenance_id" value="<?php echo htmlspecialchars($maintenance['maintenance_id']); ?>">
                            
                            <div class="form-group">
                                <label for="truckid">Truck ID:</label>
                                <input type="text" id="truckid" name="truckid" class="form-control" value="<?php echo htmlspecialchars($maintenance['truckid']); ?>">
                            </div>
                            
                            <div class="form-group">
                                <label for="routeid">Route ID:</label>
                                <input type="text" id="routeid" name="routeid" class="form-control" value="<?php echo htmlspecialchars($maintenance['routeid']); ?>">
                            </div>
                            
                            <div class="form-group">
                                <label for="maintenance_date">Maintenance Date:</label>
                                <input type="date" id="maintenance_date" name="maintenance_date" class="form-control" value="<?php echo htmlspecialchars($maintenance['maintenance_date']); ?>">
                            </div>
                            
                            <div class="form-group">
                                <label for="maintenance_type">Maintenance Type:</label>
                                <input type="text" id="maintenance_type" name="maintenance_type" class="form-control" value="<?php echo htmlspecialchars($maintenance['maintenance_type']); ?>">
                            </div>
                            
                            <div class="form-group">
                                <label for="description">Description:</label>
                                <textarea id="description" name="description" class="form-control"><?php echo htmlspecialchars($maintenance['description']); ?></textarea>
                            </div>
                            
                            <div class="form-group">
                                <label for="cost">Cost:</label>
                                <input type="text" id="cost" name="cost" class="form-control" value="<?php echo htmlspecialchars($maintenance['cost']); ?>">
                            </div>
                            
                            <div class="form-group">
                                <input type="submit" name="update" value="Update" class="btn btn-primary">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

</body>
</html>
