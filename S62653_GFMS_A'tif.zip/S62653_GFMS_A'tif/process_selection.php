<?php
session_start();

// Replace with your database connection code
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gfmsu";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get route_id from POST data
$route_id = $_POST['route_id'];

// Fetch route details from database
$sql = "SELECT id, name, location FROM routes WHERE id = $route_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $route = $result->fetch_assoc();
    // Store selected route data in session
    $_SESSION['selectedRoute'] = $route;
    // Redirect to view_selected_route.php after setting session
    header('Location: view_location.php');
    exit(); // Ensure that script execution stops after redirection
} else {
    echo json_encode(['message' => 'Error choosing route: Route not found']);
}

// Close database connection
$conn->close();
?>
