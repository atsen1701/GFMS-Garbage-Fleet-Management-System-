<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Choose Route</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-4">
        <div class="card">
            <div class="card-body">
                <h2>Choose a Route</h2>
                <form id="chooseRouteForm">
                    <div class="form-group">
                        <label for="routeSelect">Select Route:</label>
                        <select id="routeSelect" name="route_id" class="form-control">
                            <!-- Options will be populated dynamically via JavaScript -->
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="locationDisplay">Location:</label>
                        <input type="text" id="locationDisplay" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                    <label for="plateSelect">Plate Number:</label>
                    <select id="plateSelect" name="plate_number" class="form-control">
                        <!-- Options will be populated dynamically via JavaScript -->
                    </select>
                </div>
                    <button type="button" id="chooseRouteBtn" class="btn btn-primary">Choose Route</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

    <!-- Custom JavaScript -->
    <script>
      $(document).ready(function() {
    // Fetch routes and populate dropdown
    $.ajax({
        url: 'get_routes.php',
        type: 'GET',
        dataType: 'json',
        success: function(data) {
            // Clear existing options
            $('#routeSelect').empty();
            // Add fetched routes to dropdown
            $.each(data, function(index, route) {
                $('#routeSelect').append($('<option>', {
                    value: route.id,
                    text: route.name,
                    'data-location': route.location // Store location data as attribute
                }));
            });
            
            // Trigger change event initially to display default location
            $('#routeSelect').change();
        },
        error: function(xhr, status, error) {
            console.error('Error fetching routes:', error);
        }
    });

    // Fetch plate numbers and populate dropdown based on selected route
    $('#routeSelect').change(function() {
        var route_id = $(this).val();

        // Clear existing options
        $('#plateSelect').empty();

        if (route_id) {
            // Fetch plate numbers associated with the selected route
            $.ajax({
                url: 'get_plate_num.php',
                type: 'POST',  // Assuming you use POST to fetch plate numbers based on route_id
                dataType: 'json',
                data: { route_id: route_id },
                success: function(data) {
                    // Add fetched plate numbers to dropdown
                    $.each(data, function(index, plate) {
                        $('#plateSelect').append($('<option>', {
                            value: plate.no_plate,
                            text: plate.no_plate
                        }));
                    });

                    // Display the first plate number by default (optional)
                    if (data.length > 0) {
                        $('#statusDisplay').val(data[0].no_plate); // Display the first plate number in the input field
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching plate numbers:', error);
                }
            });
        }
    });

    // Update status display when a plate number is selected
    $('#plateSelect').change(function() {
        var selectedPlate = $(this).val();
        $('#statusDisplay').val(selectedPlate);
    });

    // Handle route selection
    $('#chooseRouteBtn').click(function(event) {
        event.preventDefault(); // Prevent default form submission behavior

        var route_id = $('#routeSelect').val();
        var plate_number = $('#plateSelect').val();
        
        if (route_id && plate_number) {
            // Mark the route as chosen in the database
            $.ajax({
                url: 'set_chosen_routes.php',
                type: 'POST',
                dataType: 'json',
                data: { route_id: route_id, plate_number: plate_number },
                success: function(response) {
                    if (response.success) {
                        // Redirect to TrckDash.php after successful route selection
                        window.location.href = 'TrckDash.php'; // Adjust the URL to your TrckDash.php location
                    } else {
                        console.error('Error processing route selection');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error processing route selection:', error);
                }
            });
        } else {
            console.error('No route or plate number selected');
        }
    });
});


    </script>
</body>

</html>
