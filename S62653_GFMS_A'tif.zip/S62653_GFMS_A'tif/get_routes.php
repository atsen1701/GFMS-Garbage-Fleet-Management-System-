<?php
// Replace with your database connection code
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gfmsu";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch routes from database where chosen = 0 (not chosen)
$sql = "SELECT id, name, location FROM routes WHERE chosen = 0";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $routes = array();
    while ($row = $result->fetch_assoc()) {
        $routes[] = $row;
    }
    // Return routes as JSON response
    echo json_encode($routes);
} else {
    echo json_encode([]); // Return empty array if no routes found
}

// Close database connection
$conn->close();
?>
