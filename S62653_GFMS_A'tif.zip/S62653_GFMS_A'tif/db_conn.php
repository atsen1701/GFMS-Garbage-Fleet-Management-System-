<?php

$sname= "localhost";
$uname= "root";
$password = "";

$db_name = "GFMS";

$conn = mysqli_connect($sname, $uname, $password, $db_name);



if (!$conn) {
	echo "Connection failed!";
}else{
	echo"Success";
}