<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $description = $_POST['description'];
    $date = $_POST['date'];
    $location = $_POST['location'];
    $truckid = $_POST['truckid'];
    $severity = $_POST['severity'];
    $repair_status = $_POST['repair_status'];
    $repair_date = $_POST['repair_date'];
    $cost = $_POST['cost'];

    $image = "";
    if (!empty($_FILES['image']['name'])) {
        $image = basename($_FILES['image']['name']);
        $target_dir = "C:/xampp/htdocs/TestCombine/uploads/";
        $target_file = $target_dir . $image;
        move_uploaded_file($_FILES['image']['tmp_name'], $target_file);
    }

    try {
        // Prepare SQL statement
        $sql = "INSERT INTO damagefrm (description, date, location, truckid, severity, repair_status, repair_date, cost, image) 
                VALUES (:description, :date, :location, :truckid, :severity, :repair_status, :repair_date, :cost, :image)";
        $stmt = $pdo->prepare($sql);

        // Bind parameters
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':date', $date);
        $stmt->bindParam(':location', $location);
        $stmt->bindParam(':truckid', $truckid);
        $stmt->bindParam(':severity', $severity);
        $stmt->bindParam(':repair_status', $repair_status);
        $stmt->bindParam(':repair_date', $repair_date);
        $stmt->bindParam(':cost', $cost);
        $stmt->bindParam(':image', $image);

        // Execute the query
        $stmt->execute();

        echo "Record saved successfully. Redirecting you back to the form...";
        header('refresh:3; url=addDamage.php');
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
