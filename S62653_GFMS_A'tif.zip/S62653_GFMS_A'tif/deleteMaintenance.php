<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "gfmsu";

// Create connection
$connection = new mysqli($servername, $username, $password, $database);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Check if maintenance_id is set in the URL
if (isset($_GET['id'])) {
    $maintenance_id = $_GET['id'];

    // Prepare and bind
    $stmt = $connection->prepare("DELETE FROM garbagetruckmaintenance WHERE maintenance_id = ?");
    $stmt->bind_param("i", $maintenance_id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . $connection->error;
    }

    // Close the statement
    $stmt->close();
} else {
    echo "No maintenance ID provided";
}

// Close connection
$connection->close();

// Redirect to the maintenance list page after deletion
header("Location: idxMaintenance.php");
exit();
?>
