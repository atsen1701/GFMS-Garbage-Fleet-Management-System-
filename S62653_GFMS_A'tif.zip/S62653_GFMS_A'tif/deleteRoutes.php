<?php
// Ensure that the id parameter is set and not empty
if (isset($_GET['id']) && !empty($_GET['id'])) {
    // Database connection details
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "gfmsu";

    // Create connection
    $connection = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($connection->connect_error) {
        die("Connection failed: " . $connection->connect_error);
    }

    // Prepare SQL statements to delete related maintenance records first
    $id = $_GET['id'];
    $sqlDeleteMaintenance = "DELETE FROM garbagetruckmaintenance WHERE routeid = $id";
    $connection->query($sqlDeleteMaintenance);

    // Prepare SQL statement to delete the route record
    $sqlDeleteRoute = "DELETE FROM routes WHERE id = $id";

    // Execute the delete query
    if ($connection->query($sqlDeleteRoute) === TRUE) {
        echo "Route record deleted successfully.";
    } else {
        echo "Error deleting record: " . $connection->error;
    }

    // Close connection
    $connection->close();
} else {
    echo "Invalid id parameter.";
}

// Redirect to the routes list page after deletion
header("Location: idxRoutes.php");
exit();
?>
