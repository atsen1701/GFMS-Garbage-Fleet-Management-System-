<?php
include 'db.php';

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    // Prepare the SQL statement
    $sql = "DELETE FROM checkin WHERE id=?";
    $stmt = $pdo->prepare($sql);

    try {
        $stmt->execute([$id]);

        // Check if the deletion was successful
        if ($stmt->rowCount() > 0) {
            echo "Record deleted successfully. Redirecting you back to the form...";
            header('refresh:3; url=idxArrival.php');
            exit();
        } else {
            echo "Record with ID $id not found.";
        }
    } catch (PDOException $e) {
        // Handle delete failure
        echo "Error deleting record: " . $e->getMessage();
    }
}
?>
