<?php
session_start();

// Replace with your actual database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gfmsu";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get route_id from POST data
$route_id = $_POST['route_id'];

// Validate route_id (ensure it's a number)
if (!is_numeric($route_id)) {
    echo json_encode(['success' => false, 'message' => 'Invalid route ID']);
    exit; // Stop script execution
}

// Fetch route details from the database
$sql = "SELECT id, name, location FROM routes WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $route_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $route = $result->fetch_assoc();
    // Store the selected route in the session
    $_SESSION['selectedRoute'] = $route;
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Route not found']);
}

// Close database connection
$conn->close();
?>
